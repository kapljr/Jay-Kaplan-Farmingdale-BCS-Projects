/**
 * Contains a Assignment class to generate name, grade and category for
 * assignment information.
 */
package jaykaplan.bcs345.hwk.grades.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains Assignment methods. This class sets and gets data for 
 * instances for assignment data. There are also methods that can
 * read and write to files.
 * 11/17/2015 - made some small changes to the JSON portion.
 * 
 * @author Jay Kaplan
 * @version 1.1
 * @since 10/9/2015
 *
 */
public class Assignment
{
	//*******************************************
	//Contains the assignment name.
	//*******************************************
	private String name;
	
	//*******************************************
	//Contains the grade for the assignment.
	//*******************************************
	private double grade;
	
	//*******************************************
	//Contains the category for the assignment
	//(Exam, Homework, Quiz, or Lab).
	//*******************************************
	private String category;
		
	/**
	 * This method is the default constructor.
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public Assignment()
	{
		name = "";
		grade = 0.0;
		category = "";
	}
	
	/**
	 * This method sets the String name which is
	 * the assignments name.
	 * 
	 * @param name Value of assignments name.
	 * @return not used.
	 */
	public void setName(String name)
	{
		this.name = name;
	}
	
	/**
	 * This method gets the String Name which is the
	 * assignments name.
	 * 
	 * @param not used.
	 * @return Returns the value in of the assignment name.
	 */
	public String getName()
	{
	      return name; 
	} 

	/**
	 * This method sets the double grade and checks to
	 * make sure that grade is a value over zero.
	 * 
	 * @param grade Value of assignment grade.
	 * @return not used.
	 */
	public void setGrade(double grade)
	{
		// test that grade is above zero.
		if (grade >= 0)
		{
			this.grade = grade;
		}
	}
	
	/**
	 * This method gets the double grade. 
	 * 
	 * @param not used.
	 * @return grade Value of assignment grade.
	 */
	public double getGrade()
	{
	    return grade; 
	} 
	
	/**
	 * This method sets the String category. 
	 * 
	 * @param category Value of assignments category.
	 * @return not used.
	 */
	public void setCategory(String category)
	{
		this.category = category;
	}
	
	/**
	 * This method gets the String category.
	 * 
	 * @param not used.
	 * @return Returns the value in category.
	 */
	public String getCategory()
	{
	    return category; 
	} 
	
	/**
	 * This method Writes to the PrintStream
	 * file using the 3 member variables in the
	 * Assignment class. 
	 * 
	 * @param ps Value of PrintStream File.
	 * @return not used.
	 */
	public void Write(PrintStream ps)
	{
		ps.println(name);
		ps.println(grade);
		ps.println(category);
	}
	
	/**
	 * This method Reads the variables from the
	 * open file in the Assignment Class.
	 * 
	 * @param s Value of Scanner open file.
	 * @return not used.
	 */
	public void Read(Scanner r)
	{   
		this.name = r.nextLine();
		this.grade = r.nextDouble();
		r.nextLine();
		this.category = r.nextLine();
	}
	
	/**
	 * This method overrides the toString in the Assignment Class
	 * to create a JSON construction of strings.
	 * 
	 * @param not used.
	 * @return s Used for returning the JSON value of the 4
	 * member variables.
	 */
	@Override
	public String toString()
	{
		String s = "    {\"name\":\"";
		s += name;
		s += "\",\"grade\":";
		s += grade;
		s += ",\"category\":\"";
		s += category;
		s += "\"}";

		return s;
	}
	
	/**
	 * This method overrides the equals which is used
	 * for comparing two strings within the Assignment class.
	 * 
	 * @param obj This creates an object used for the instance comparison.
	 * @return not used.
	 */
	@Override
	public boolean equals(Object obj)
	{
		Assignment other = (Assignment)obj;
		
		if(name.equals(other.name)==false)
			return false;
		
		if(category.equals(other.category)==false)
			return false;
		
		return true;
	}
}
