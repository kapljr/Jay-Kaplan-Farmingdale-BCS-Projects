/**
 * Contains CourseMember Class
 * This package holds the CourseMember Class.
 * 
 */
package jaykaplan.bcs345.hwk.grades.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains CourseMember Class and its methods. 
 * 
 * @author Jay Kaplan
 * @version 1.0
 * @since 11/23/2015
 *
 */
public class CourseMember 
{
	//holds student name and major
	private Student student;
	
	//holds data about assignments
	private AssignmentCollection assignments;
	
	/**
	 * This method is the default constructor.
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public CourseMember()
	{
		student = new Student();
		assignments = new AssignmentCollection();
	}
	
	/**
	 * This method sets the Student data.
	 * 
	 * @param student Value of student name and major.
	 * @return not used.
	 */
	public void setStudent(Student student)
	{
		this.student = student;
	}
	
	/**
	 * This method sets the Assignment data.
	 * 
	 * @param assignments Value of data about assignments.
	 * @return not used.
	 */
	public void setAssignments(AssignmentCollection assignments)
	{
		this.assignments = assignments;
	}
	
	/**
	 * This method gets the Student data.
	 * 
	 * @param not used.
	 * @return Returns the value in student.
	 */
	public Student getStudent()
	{
	      return student; 
	} 
	
	/**
	 * This method gets the assignment data.
	 * 
	 * @param not used.
	 * @return Returns the value in assignments.
	 */
	public AssignmentCollection getAssignments()
	{
	      return assignments; 
	} 
	
	/**
	 * This method gets data to the PrintStream.
	 * 
	 * @param ps Prints to the PrintStream.
	 * @return not used.
	 */
	public void Write(PrintStream ps) throws Exception
	{
		ps.printf("%s \n", student.getFirst());
		ps.printf("%s \n", student.getLast());
		ps.printf("%d \n", student.getId());
		ps.printf("%s \n", student.getMajor());
		assignments.Write(ps);
	}//end of Write
	
	/**
	 * This method read in data to the Scanner.
	 * 
	 * @param r Reads data to the Scanner.
	 * @return not used.
	 */
	public void Read(Scanner r) throws Exception
	{ 
		student.setFirst(r.nextLine());
		student.setLast(r.nextLine());
		student.setId(r.nextInt());
		r.nextLine();
		student.setMajor(r.nextLine());
		assignments.Read(r);
	}//end of Read
	
	/**
	 * This method prints a report to the screen through the 
	 * print stream. It uses the for each loop to iterate through
	 * different assignments.
	 * 
	 * @param ps Prints the report to the PrintStream
	 * @return not used.
	 */
	public void Report(PrintStream ps)
	{
		//****************************************************
		//Setting up Report for Printing to File
		//****************************************************
		ps.printf("%nCourse Member Report%n");
		ps.printf("--------------------%n%n");
		
		//****************************************************
		//Sets up Student Name, ID and Major.
		//****************************************************
		ps.printf("First: %s%n",student.getFirst());
		ps.printf("Last: %s%n",student.getLast());
		ps.printf("Id: %d%n",student.getId());
		ps.printf("Major: %s%n%n",student.getMajor());
		
		//****************************************************
		//Sets up Column Headers for report format.
		//****************************************************
		String column1 = "Assignment";
		String column2 = "Category";
		String column3 = "Grade";
		ps.printf("%-20s%-15s%10s%n",column1,column2,column3);
		String under1 = "----------";
		String under2 = "--------";
		String under3 = "-----";
		ps.printf("%-20s%-15s%10s%n",under1,under2,under3);  
		
		//****************************************************
		//These are variables used for counting total 
		//in a category and summing grades.
		//****************************************************
		double hwGrade = 0, examGrade = 0, quizGrade = 0, labGrade = 0;
		double hwCount = 0, examCount = 0, quizCount = 0, labCount = 0;
		
		//****************************************************
		//for loop that iterates through the records.
		//****************************************************
		//FOR EACH
		for (Assignment a : assignments)
		{
			//****************************************************
			//Each record is read into a variable in this order:
			//String for Assignment Name
			//Double for Grade
			//String for Category
			//****************************************************
			
			String assignmentName = a.getName();
    		double grade = a.getGrade();
    		String category = a.getCategory();
  		
			//****************************************************
			//While the record is read in String, double, String
       		//it is printed String, String, double for formatting.
			//****************************************************
    		ps.printf("%-20s%-15s%10.1f%n",assignmentName,category,grade);
    		
    		//****************************************************
    		//if else is used to sum up grades and 
    		//categorize them for summary.
    		//****************************************************
    		if(category.equals("Homework"))
    		{
    			hwGrade = hwGrade + grade;
    			hwCount++;
    		} 
    		else if(category.equals("Lab"))
    		{
    			labGrade = labGrade + grade;
    			labCount++;
    		}
    		else if(category.equals("Exam"))
    		{
    			examGrade = examGrade + grade;
    			examCount++;
    		}
    		else
    		{
    			quizGrade = quizGrade + grade;
    			quizCount++;
    		}
        }//end of for each loop
		
		//****************************************************
		//This is the Category Summary that prints at the
		//bottom of the report.
		//****************************************************
		ps.printf("%nCategory Summary%n");
		ps.printf("----------------%n");
		ps.printf("Homework: %.2f%%%n",hwGrade/=hwCount);
		ps.printf("Exam    : %.2f%%%n",examGrade/=examCount);
		ps.printf("Quiz    : %.2f%%%n",quizGrade/=quizCount);
		ps.printf("Lab     : %.2f%%%n%n",(labGrade/=labCount)*100);
	}// end of report method
	
	/**
	 * This method prints JSON data to the screen and overrides the toString
	 * 
	 * @param not used.
	 * @return not used.
	 */
	@Override
	public String toString()
	{
		if (this.assignments == null)
		{
			return null;
		}
		//****************************************************
		// Creates the JSON for the toString
		//****************************************************
		String s = "{\n";
		s += "  \"student\":\n";
		//s += "  { \"first\": \"";
		//s += student.getFirst();
		//s += "\", \"last\": \"";
		//s += student.getLast();
		//s += "\", \"id\": ";
		//s += student.getId();
		//s += ", \"major\": \"";
		//s += student.getMajor();
		s += student.toString();
		s += ",\n";
				
		String comma = "";
		s += "  \"assignments\":\n";
		s += "  [\n";
		for (Assignment a : assignments)	
		{
			s += comma;
			s += a.toString();
			//s += "   {\"name\":\"";
			//s += a.getName();
			//s += "\",\n   \"grade\": ";
			//s += a.getGrade();
			//s += ",\n   \"category\":\"";
			//s += a.getCategory();
			//s += "\"   \n}";
			comma = ",\n";
		}// end of for loop
		s += "\n  ]\n";
		s += "}\n";
		
		return s;
	}//end of toString
}// End of class course member
