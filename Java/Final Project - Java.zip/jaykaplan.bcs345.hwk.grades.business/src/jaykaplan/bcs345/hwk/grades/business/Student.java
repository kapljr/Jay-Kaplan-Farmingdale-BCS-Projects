/**
 * Contains the Student class to generate fist and last name, id and major for
 * student information.
 */
package jaykaplan.bcs345.hwk.grades.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains Student methods. This class sets and gets data for 
 * instances for Student data. There are also methods that can
 * read and write to files.
 * 
 * @author Jay Kaplan
 * @version 1.1
 * @since 11/19/2015
 *
 */
public class Student
{
	//*******************************************
	//Contains the student�s first name
	//*******************************************
	private String first;
	
	//*******************************************
	//Contains the student�s last name.
	//*******************************************
	private String last;
	
	//*******************************************
	//Contains the student�s id.
	//*******************************************
	private int id;
	
	//*******************************************
	//Contains the student�s major.
	//*******************************************
	private String major;
	
	
	/**
	 * This method is the default constructor.
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public Student()
	{
		first = "";
		last = "";
		id = 0;
		major = "";
	}
	
	/**
	 * This method sets the String first.
	 * 
	 * @param first Value of first name.
	 * @return not used.
	 */
	public void setFirst(String first)
	{
		this.first = first;
	}
	
	/**
	 * This method gets the String first.
	 * 
	 * @param not used.
	 * @return Returns the value in first.
	 */
	public String getFirst()
	{
	      return first; 
	} 

	/**
	 * This method sets the String last.
	 * 
	 * @param last Value of last name.
	 * @return not used.
	 */
	public void setLast(String last)
	{
		this.last = last;
	}
		
	/**
	 * This method gets the String last.
	 * 
	 * @param not used.
	 * @return Returns the value in last.
	 */
	public String getLast()
	{
	      return last; 
	} 
	
	/**
	 * This method sets the int id and checks to
	 * make sure that ID is a value over zero.
	 * 
	 * @param id Value of student id.
	 * @return not used.
	 */
	public void setId(int id)
	{
		// tests that id is greater than zero
		if (id >= 0) 
		{
			this.id = id;
		}
	}
	
	/**
	 * This method gets the int id.
	 * 
	 * @param not used.
	 * @return Returns the value in id.
	 */
	public int getId()
	{
	      return id; 
	} 
	
	/**
	 * This method sets the String major.
	 * 
	 * @param major Value of student's major.
	 * @return not used.
	 */
	public void setMajor(String major)
	{
		this.major = major;
	}
	
	/**
	 * This method gets the String major.
	 * 
	 * @param not used.
	 * @return Returns the value in major.
	 */
	public String getMajor()
	{
	      return major; 
	} 
	
	/**
	 * This method Writes to the PrintStream
	 * file using the 4 member variables in the Student class. 
	 * 
	 * @param ps Value of PrintStream File.
	 * @return not used.
	 */
	public void Write(PrintStream ps)
	{
		ps.println(first);
		ps.println(last);
		ps.println(id);
		ps.println(major);
	}
	
	/**
	 * This method Reads the variables from the
	 * open file in the Student class.
	 * 
	 * @param s Value of Scanner open file.
	 * @return not used.
	 */
	public void Read(Scanner s)
	{
		this.first = s.nextLine();
		this.last = s.nextLine();
		this.id = s.nextInt();
		s.nextLine();
		this.major = s.nextLine();
		s.close();
	}
	
	/**
	 * This method overrides the toString to
	 * create a JSON construction of strings
	 * in the Student class.
	 * 
	 * @param not used.
	 * @return s Used for returning the JSON value of the 4
	 * member variables.
	 */
	@Override
	public String toString()
	{
			
		String s = "  {\"first\":\"";
		s += first;
		s += "\",\"last\":\"";
		s += last;
		s += "\",\"id\":";
		s += id;
		s += ",\"major\":\"";
		s += major;
		s += "\"}";
	
		return s;
	}
	
	/**
	 * This method overrides the equals which is used
	 * for comparing two strings within the Student class.
	 * 
	 * @param obj This creates an object used for the instance comparison.
	 * @return not used.
	 */
	@Override
	public boolean equals(Object obj)
	{
		Student other = (Student)obj;
		
		if(first.equals(other.first)==false)
			return false;
		
		if(last.equals(other.last)==false)
			return false;
		
		if(major.equals(other.major)==false)
			return false;
		
		return true;
	}
}
