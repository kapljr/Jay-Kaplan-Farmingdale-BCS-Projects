/**
 * Contains a Assignment Collection Class
 * This package holds the Assignment Collection Class
 * and its methods that feed the menu for the
 * Assignment Collection Console UI 
 */
package jaykaplan.bcs345.hwk.grades.business;

import java.io.PrintStream;
import java.util.Scanner;
import java.util.Iterator;

/**
 * Contains Assignment Collection Class and its methods. 
 * This class holds 7 different methods that are used and called
 * in the Assignment Collection Console
 * 
 * This class now implements the Iterable interface.
 * 
 * @author Jay Kaplan
 * @version 2.0
 * @since 11/19/2015
 *
 */
public class AssignmentCollection implements Iterable<Assignment>
{
	public double hwGrade = 0, examGrade = 0, quizGrade = 0, labGrade = 0, overallGrade = 0;
	public double hwCount = 0, examCount = 0, quizCount = 0, labCount = 0;
	//*************************************************
	//This variable creates an array of Assignment.
	//*************************************************
	private Assignment[] assignments;
	
	/**
	 * This method is the default constructor.
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public AssignmentCollection()
	{
		this.assignments = null;
	}
	
	/**
	 * This method searches the array for the assignment
	 * with the given name and returns it. 
	 *  
	 * @param name Value of assignment name in a specific element.
	 * @return assignments[i] Value of the name specified from use input.
	 */
	public Assignment GetByName(String name)
	{
		//****************************************************
		// Returns null if assignments is empty
		//****************************************************
		if (this.assignments == null)
		{
			return null;
		}
			
		//****************************************************
		// Iterates through assignments to located the
		// element by the user supplied name.
		//****************************************************
		for (int i = 0; i < assignments.length; i++)
		{
			if (assignments[i].getName().equals(name))
			{
				return assignments[i];
			}// end of if
		} // end of for
		return null;
	} //end of GetByName
	
	/**
	 * This method returns the assignment at a given index. It throws
	 * an exception if the index is invalid. 
	 *  
	 * @param index Value of assignment name in a specific element.
	 * @return assignments[i] Value of the index specified from use input.
	 */
	public Assignment GetByIndex(int index)
	{
		//****************************************************
		// Returns null if assignments is empty
		//****************************************************
		if (this.assignments == null)
		{
			return null;
		}
		
		//****************************************************
		// next two if statements check for out of bounds exceptions
		//****************************************************
		if (index < 0)
			throw new ArrayIndexOutOfBoundsException("No negative index's allowed");
		
		if (index > assignments.length)
			throw new ArrayIndexOutOfBoundsException("Index is too large");
		
		return assignments[index];
	}
	
	/**
	 * This method writes a report to the screen using the PrintStream.
	 * It uses the format from a previous HW assignment for the structure.
	 *  
	 * @param ps Value of the PrintStream.
	 * @return not used.
	 */
	public void Report(PrintStream ps)
	{
		if (this.assignments == null)
		{
			return;
		}
		
		//****************************************************
		//Sets up Column Headers for report format.
		//****************************************************
		String column1 = "\nAssignment";
		String column2 = "Category";
		String column3 = "Grade";
		ps.printf("%-20s%-15s%10s%n",column1,column2,column3);
		String under1 = "----------";
		String under2 = "--------";
		String under3 = "-----";
		ps.printf("%-20s%-15s%10s%n",under1,under2,under3);  
		
		//****************************************************
		//These are variables used for counting total 
		//in a category and summing grades.
		//****************************************************
		double hwGrade = 0, examGrade = 0, quizGrade = 0, labGrade = 0;
		double hwCount = 0, examCount = 0, quizCount = 0, labCount = 0;
		
		//****************************************************
		//old for loop that iterates through the records.
		//LEFT IN FOR MY REFERENCE ONLY
		//****************************************************
		/*
		for (int i = 0; i < assignments.length; i++)
		{
			//****************************************************
			//Each record is read into a variable in this order:
			//String for Assignment Name
			//Double for Grade
			//String for Category
			//****************************************************
			Assignment a = assignments[i];
			String assignmentName = a.getName();
    		double grade = a.getGrade();
    		String category = a.getCategory();
  		
			//****************************************************
			//While the record is read in String, double, String
       		//it is printed String, String, double for formatting.
			//****************************************************
    		ps.printf("%-20s%-15s%10.1f%n",assignmentName,category,grade);
    		
    		//****************************************************
    		//if else is used to sum up grades and 
    		//categorize them for summary.
    		//****************************************************
    		if(category.equals("Homework"))
    		{
    			hwGrade = hwGrade + grade;
    			hwCount++;
    		} else if(category.equals("Lab"))
    		{
    			labGrade = labGrade + grade;
    			labCount++;
    		} else if(category.equals("Exam"))
    		{
    			examGrade = examGrade + grade;
    			examCount++;
    		} else
    		{
    			quizGrade = quizGrade + grade;
    			quizCount++;
    		}
        }//end of for loop
		*/
		//****************************************************
		//updated for "each" loop that iterates through the records.
		//****************************************************
		for (Assignment a : assignments)
		{
			//****************************************************
			//Each record is read into a variable in this order:
			//String for Assignment Name
			//Double for Grade
			//String for Category
			//****************************************************
			
			String assignmentName = a.getName();
    		double grade = a.getGrade();
    		String category = a.getCategory();
  		
			//****************************************************
			//While the record is read in String, double, String
       		//it is printed String, String, double for formatting.
			//****************************************************
    		ps.printf("%-20s%-15s%10.1f%n",assignmentName,category,grade);
    		
    		//****************************************************
    		//if else is used to sum up grades and 
    		//categorize them for summary.
    		//****************************************************
    		if(category.equals("Homework"))
    		{
    			hwGrade = hwGrade + grade;
    			hwCount++;
    		} else if(category.equals("Lab"))
    		{
    			labGrade = labGrade + grade;
    			labCount++;
    		} else if(category.equals("Exam"))
    		{
    			examGrade = examGrade + grade;
    			examCount++;
    		} else
    		{
    			quizGrade = quizGrade + grade;
    			quizCount++;
    		}
        }//end of for each loop
		//****************************************************
		//This is the Category Summary that prints at the
		//bottom of the report.
		//****************************************************
		ps.printf("%nCategory Summary%n");
		ps.printf("----------------%n");
		ps.printf("Homework: %.2f%%%n",hwGrade/=hwCount);
		ps.printf("Exam    : %.2f%%%n",examGrade/=examCount);
		ps.printf("Quiz    : %.2f%%%n",quizGrade/=quizCount);
		ps.printf("Lab     : %.2f%%%n%n",(labGrade/=labCount)*100);
	}
	
	/**
	 * This method reads the contents of the member variables
	 * of a given instance. It uses count as the size of the array
	 * which is the first line of the file.
	 *  
	 * @param r Value of the filename being read.
	 * @return not used.
	 */
	public void Read(Scanner r)
	{   
		//****************************************************
		// Reads in the file supplied by the user
		//****************************************************
		int count = r.nextInt();
		r.nextLine();		
		assignments = new Assignment[count];
		
		//****************************************************
		// Iterates through the file
		//****************************************************
		for(int i = 0; i < count; i++)
		{
			assignments[i] = new Assignment();
			assignments[i].Read(r);
		}//end of for loop
	}//end of read
	
	/**
	 * This method writes to the output file name.
	 * 	 *  
	 * @param ps Value of the PrintStream.
	 * @return not used.
	 */
	public void Write(PrintStream ps)
	{
		if (this.assignments == null)
		{
			return;
		}
		
		//****************************************************
		// Change made**
		// Added count to the top of the Write file.
		//****************************************************
		int count = assignments.length;
		ps.println(count);
		
		//****************************************************
		// Iterates through assignments and writes to PrintStream
		//****************************************************
		
		for(int i = 0; i < assignments.length; i++)
		{
			assignments[i].Write(ps);
		}
	}//end of Write
	
	/**
	 * This method overrides the toString to create a 
	 * JSON construction of strings. This was modified from the
	 * assignment class as the specifications looked different.
	 * 
	 * @param not used.
	 * @return s Value used for returning the JSON value of the 
	 * member variables.
	 */
	@Override
	public String toString()
	{
		if (this.assignments == null)
		{
			return null;
		}
		//****************************************************
		// Creates the JSON for the toString
		//****************************************************
		String s = "[\n";
		for(int i = 0; i < assignments.length; i++)
		{
			s += "{\"name\":\"";
			s += assignments[i].getName();
			s += "\",\"grade\":";
			s += assignments[i].getGrade();
			s += ",\"category\":\"";
			s += assignments[i].getCategory();
			
			if (assignments.length-1 == i)
			{
				s += "\"}\n";		
			}
			else
			{
				s += "\"},\n";
			}	
		}// end of for loop
		s += "]\n";
		
		return s;
	}//end of toString
	
	/**
	 * Private inner class AssignIter that implements Iterator <Assignment>
	 * 
	 * @author Jay Kaplan
	 * @version 1.0
	 * @since 11/19/2015
	 *
	 */
	private class AssignIter implements Iterator<Assignment>
	{
		private int index = 0;
		
		/**
		 * This method overrides the hasNext for the interface.
		 * 
		 * @param not used.
		 * @return value of has next if index less than the array length.
		 */
		@Override
		public boolean hasNext() 
		{
						
			return index < assignments.length;
		}

		/**
		 * This method overrides the next for the interface.
		 * 
		 * @param not used.
		 * @return iterates the next index of assignment
		 */
		@Override
		public Assignment next() 
		{
			
			return assignments[index++];
		}
	}//end of private class AssignIter

	/**
	 * This method overrides the Iterator Assignment.
	 * 
	 * @param not used.
	 * @return new AssignIter
	 */
	@Override
	public Iterator<Assignment> iterator() 
	{
		
		return new AssignIter();
	}
	
	/**
	 * This method finds the grade averages for the Assignment Collection.
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public void findGradeAvg()
	{
		//***************************************************
		//These variables used in calculating and counting 
		//for the loop and show up in the window, I kept the
		//original name for these variables when they should
		//have probably been changed to Avg.
		//***************************************************
		hwGrade = 0;
		examGrade = 0;
		quizGrade = 0;
		labGrade = 0;
		overallGrade = 0;
		hwCount = 0;
		examCount = 0;
		quizCount = 0;
		labCount = 0;
		//****************************************************
		//for loop that iterates through the records.
		//****************************************************
		//FOR EACH
		for (Assignment a : assignments)
		{
			//****************************************************
			//Each record is read into a variable in this order:
			//String for Assignment Name
			//Double for Grade
			//String for Category
			//****************************************************
    		double grade = a.getGrade();
    		String category = a.getCategory();
  			//****************************************************
    		//if else is used to sum up grades and 
    		//categorize them for summary.
    		//****************************************************
    		if(category.equals("Homework"))
    		{
    			hwGrade = hwGrade + grade;
    			hwCount++;
    		} else if(category.equals("Lab"))
    		{
    			labGrade = labGrade + grade;
    			labCount++;
    		} else if(category.equals("Exam"))
    		{
    			examGrade = examGrade + grade;
    			examCount++;
    		} else
    		{
    			quizGrade = quizGrade + grade;
    			quizCount++;
    		}
        }//end of for each loop
		hwGrade/=hwCount;
		examGrade/=examCount;
		quizGrade/=quizCount;
		labGrade=(labGrade/labCount)*100;
		//% taken from Syllabus.
		overallGrade=(hwGrade*.35)+(examGrade*.5)+(quizGrade*.10)+(labGrade*.05);
	}//end of findGradeAvg method.
}//end of Assignment Collection class

