/**
 * Contains a Main class to generate Automated Test Program of Business Package.
 */
package jaykaplan.bcs345.hwk.grades.presentation;

import java.util.Scanner;

/**
 * Contains Main ShowUI method which is an instance of AssignmentCollectionUI
 * and CourseMemberUI. This class generates an call to the Menu for 
 * BCS345 HomeWork5 Main Console UI.
 * 
 * Updated this method so that the user is now given another 
 * choice of which user interface to use. 
 * 
 * @author Jay Kaplan
 * @version 2.0
 * @since 12/4/2015
 *
 */
public class Main 
{
	
	/**
	 * This is the main method for running the main console UI.
	 * The user can choose to run the Assignment Collection UI or
	 * the new Course Member UI.
	 *
	 * @param args are not used
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception 
	{
			Scanner scn = new Scanner(System.in);

			//*************************************************
			//choice is the selection for the menu, its an int.
			//*************************************************
			int choice = 0;
			
			//*************************************************
			//Start of the loop for the menu.
			//*************************************************
			do
			{
				//*************************************************
				//This resets any previous choices
				//*************************************************
				choice = 0;
				
				//*************************************************
				//System dot out statements to output the menu
				//options.
				//*************************************************
				System.out.printf("Choose UI%n");
				System.out.printf("---------%n");
				System.out.printf("1 � AssignmentCollectionConsoleUI%n");
				System.out.printf("2 � CourseMemberConsoleUI%n");
				System.out.printf("3 � CourseMemberSwingUI%n");
				System.out.printf("4 � Exit%n");
				
				//*************************************************
				//Asks for choice from the user and then inputs it
				//into the variable decision.
				//*************************************************
				System.out.printf("Enter your choice: ");
				
				//*************************************************
				//Validates bad decision data from the user.
				//*************************************************
				
				if (scn.hasNextInt() == false)
		            {
		                scn.next();
						System.out.println("Error: Your choice needs to be an integer 1 thru 7!");
						choice = 0;
		            }
				else 
				{
					choice = scn.nextInt();
				}
					
				if (choice == 1)
				{

					//******************************************************
					//Creates an instance of Assignment Collection Menus.
					//******************************************************
					AssignmentCollectionConsoleUI showACUI = new AssignmentCollectionConsoleUI();
					showACUI.ShowUI();
				}//end of choice 1
				
				else if (choice == 2)
				{
					//******************************************************
					//Creates an instance of Collection Member Menus.
					//******************************************************
					CourseMemberConsoleUI showCMUI = new CourseMemberConsoleUI();
					showCMUI.ShowUI();
				}//end of choice 2
				
				else if (choice == 3)
				{
					//******************************************************
					//Creates an instance of Course Member Swing Menus.
					//This was added in for HW5
					//******************************************************
					CourseMemberSwingUI showCMSUI = new CourseMemberSwingUI();
					showCMSUI.ShowUI();
					System.out.println("\n\nClick on the new Window to View GUI\n\n");
				}//end of choice 3
				
				else if (choice == 4)
				{
					System.exit(0);
				} // end of choice 4
			}
			while(choice!=4);//end of while loop
			scn.close();
	}// end of main method
} // end of main class
