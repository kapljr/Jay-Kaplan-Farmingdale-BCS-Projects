/**
 * Contains a Course Member Collection Console UI
 * This program presents a menu to the user and then performs an action
 * depending on which choice the user chooses.
 * Each time the program is run, it displays the menu, asks for input
 * and then after performing the action, it re-displays the menu, unless
 * choice exit is selected in which case it ends the program 
 */
package jaykaplan.bcs345.hwk.grades.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import jaykaplan.bcs345.hwk.grades.business.CourseMember;

/**
 * Contains Course Member Collection Console UI methods. 
 * This class creates a menu to the user and then perform 
 * an action depending on what the user chooses to do. 
 * When the program runs it display's the menu to the user and 
 * gives them a chance to input a choice.
 * 
 * @author Jay Kaplan
 * @version 1.0
 * @since 11/19/2015
 *
 */
public class CourseMemberConsoleUI 
{
	/**
	 * This method shows the Course Member UI. 
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public void ShowUI() throws Exception
	{
		//*************************************************
		//choice is the selection for the menu, its an int.
		//*************************************************
		int choice = 0;
		
		//*************************************************
		//Creates an instance of Course Member.
		//*************************************************
		CourseMember a1 = new CourseMember();
		
		Scanner scn = new Scanner(System.in);
		
		//*************************************************
		//Start of the loop for the menu.
		//*************************************************
		do
		{
			//*************************************************
			//This resets any previous choices
			//*************************************************
			choice = 0;
			
			//*************************************************
			//System dot out statements to output the menu
			//options.
			//*************************************************
			System.out.printf("%nCourse Member Collection UI%n");
			System.out.printf("----------------------------%n");
			System.out.printf("1 � Read course member from file%n");
			System.out.printf("2 � Write course member to file%n");
			System.out.printf("3 � Show course member  report on screen%n");
			System.out.printf("4 � Show course member JSON on string%n");
			System.out.printf("5 � Show AssignmentCollection using for-each%n");
			System.out.printf("6 - Exit%n");
			
			//*************************************************
			//Asks for choice from the user and then inputs it
			//into the variable decision.
			//*************************************************
			System.out.printf("Enter your choice: ");
			
			//*************************************************
			//Validates bad decision data from the user.
			//*************************************************
			if (scn.hasNextInt() == false)
            {
                scn.next();
				System.out.println("Error: Your choice needs to be an integer 1 thru 7!");
				choice = 0;
            }
			else 
			{
				choice = scn.nextInt();
			}
				
			//*************************************************
			//if statement for choice 1 which reads in data
			//from a user specified file into the AssignmentCollection
			//instance. Data comes from the AssignmentCollection
			//file format. The user is prompted for the filename.
			//*************************************************
			if (choice == 1)
			{
				//*************************************************
				//Block of code that asks for inputFilename
				//*************************************************
				String inputFileName;
				System.out.printf("Enter name of your input file: ");
				inputFileName = scn.next();		
				//***************************************************
				// Try and Catch for reading inputFileName
				//***************************************************
				try 
				{
					a1.Read(new Scanner(new FileReader(inputFileName)));
				} 
				catch (FileNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}//end of choice 1
			
			//*************************************************
			//else if statement for choice 2 which writes data to a
			//file from the AssignmentCollection instance. The
			//user is prompted to enter the filename to write
			//the data to. 
			//*************************************************
			else if (choice == 2)
			{
				//*************************************************
				//Block of code that asks for outputFileName
				//*************************************************
				String outputFileName;
				System.out.printf("Enter name of your output file: ");
				outputFileName = scn.next();
				
				//***************************************************
				// Try and Catch for PrintStream of outputFileName
				//***************************************************
				try
		    	{
					a1.Write(new PrintStream(outputFileName));
					
		    	}
		    	catch (Exception e)
		    	{
		    		System.out.println("ERROR. Could not open file!");
		    	}
			}//end of choice 2
			
			//*************************************************
			//else if statement for choice 3 which is to show the
			//assignment by index. 
			//*************************************************
			else if (choice == 3)
			{
				PrintStream ps = System.out;
				a1.Report(ps);
			} // end of choice 3
			
			//*************************************************
			//else if statement for choice 4 which is to show
			//assignment by name.
			//*************************************************
			else if (choice == 4)
			{
				System.out.println(a1.toString());
			}//end of choice 4
			
			//*************************************************
			//else if statement for choice 5 which is to show
			//all data as JSON
			//*************************************************			
			else if (choice == 5)
			{
				PrintStream ps = System.out;
				a1.getAssignments().Report(ps); 
			}// end of choice 5
			
			//*************************************************
			//else if statement for choice 6 which is to show
			//all data as a report to the screen.
			//*************************************************	
			else 
			{
				choice = 6;
			}
		} 
		while(choice!=6);//end of while loop
	}// end of voidShowUI
}//End of Class CourseMemberConsoleUI
