/**
 * Contains a Assignment Collection Console UI
 * This program presents a menu to the user and then performs one 
 * of 7 actions depending on which choice the user chooses.
 * Each time the program is run, it displays the menu, asks for input
 * and then after performing the action, it re-displays the menu, unless
 * choice #7 is selected in which case it ends the program 
 */
package jaykaplan.bcs345.hwk.grades.presentation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import jaykaplan.bcs345.hwk.grades.business.Assignment;
import jaykaplan.bcs345.hwk.grades.business.AssignmentCollection;

/**
 * Contains Assignment Collection Console UI methods. 
 * This class creates a menu with 7 options for accessing the Assignment Array Data 
 * There are methods that can read and write to files, and print data to the screen
 * in various formats, such as standard reporting and JSON.
 * 
 * @author Jay Kaplan
 * @version 2.0
 * @since 11/19/2015
 *
 */
public class AssignmentCollectionConsoleUI 
{
	/**
	 * This method shows the Assignment Collection Console 
	 * user interface. It displays the menu to the user when called.
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public void ShowUI()
	{
		//*************************************************
		//choice is the selection for the menu, its an int.
		//*************************************************
		int choice = 0;
		
		//*************************************************
		//Creates an instance of Assignment Collection.
		//*************************************************
		AssignmentCollection a1 = new AssignmentCollection();
		
		Scanner scn = new Scanner(System.in);
		
		//*************************************************
		//Start of the loop for the menu.
		//*************************************************
		do
		{
			//*************************************************
			//This resets any previous choices
			//*************************************************
			choice = 0;
			
			//*************************************************
			//System dot out statements to output the menu
			//options.
			//*************************************************
			System.out.printf("%nAssignment Collection UI%n");
			System.out.printf("----------------------------%n");
			System.out.printf("1 � Read assignment collection from file%n");
			System.out.printf("2 � Write assignment collection to file%n");
			System.out.printf("3 � Show assignment by index%n");
			System.out.printf("4 � Show assignment by name%n");
			System.out.printf("5 � Show assignment collection as JSON string%n");
			System.out.printf("6 - Show assignment collection report on screen%n");
			System.out.printf("7 - Exit%n");
			
			//*************************************************
			//Asks for choice from the user and then inputs it
			//into the variable decision.
			//*************************************************
			System.out.printf("Enter your choice: ");
			
			//*************************************************
			//Validates bad decision data from the user.
			//*************************************************
			if (scn.hasNextInt() == false)
	            {
	                scn.next();
					System.out.println("Error: Your choice needs to be an integer 1 thru 7!");
					choice = 0;
	            }
			else 
			{
				choice = scn.nextInt();
			}
				
			//*************************************************
			//if statement for choice 1 which reads in data
			//from a user specified file into the AssignmentCollection
			//instance. Data comes from the AssignmentCollection
			//file format. The user is prompted for the filename.
			//*************************************************
			if (choice == 1)
			{
				//*************************************************
				//Block of code that asks for inputFilename
				//*************************************************
				String inputFileName;
				System.out.printf("Enter name of your input file: ");
				inputFileName = scn.next();		
				//***************************************************
				// Try and Catch for reading inputFileName
				//***************************************************
				try 
				{
					a1.Read(new Scanner(new FileReader(inputFileName)));
				} 
				catch (FileNotFoundException e1) 
				{
					e1.printStackTrace();
				}
			}//end of choice 1
			
			//*************************************************
			//else if statement for choice 2 which writes data to a
			//file from the AssignmentCollection instance. The
			//user is prompted to enter the filename to write
			//the data to. 
			//*************************************************
			else if (choice == 2)
			{
				//*************************************************
				//Block of code that asks for outputFileName
				//*************************************************
				String outputFileName;
				System.out.printf("Enter name of your output file: ");
				outputFileName = scn.next();
				
				//***************************************************
				// Try and Catch for PrintStream of outputFileName
				//***************************************************
				try
		    	{
					a1.Write(new PrintStream(outputFileName));
					
		    	}
		    	catch (Exception e)
		    	{
		    		System.out.println("ERROR. Could not open file!");
		    	}
			}//end of choice 2
			
			//*************************************************
			//else if statement for choice 3 which is to show the
			//assignment by index. 
			//*************************************************
			else if (choice == 3)
			{
				System.out.printf("Enter the Assignment Index: ");
				
				//***************************************************
				// Try and Catch for GetByIndex of AssignmentCollection
				//***************************************************
				try
				{
					int arrayIndex = scn.nextInt();
										
					if (a1.GetByIndex(arrayIndex)== null)
					{
						System.out.println("That index is empty");
					}
					else
					{
						Assignment a = a1.GetByIndex(arrayIndex);
					
						String s;
						s = a.getName();
						s += "\n";
						s += a.getGrade();
						s += "\n";
						s += a.getCategory();
						s += "\n\n";
						System.out.printf("%s",s);
					}
				}//end of try block
			    catch (ArrayIndexOutOfBoundsException e) 
				{
			        System.out.println("Array Index Out of Bounds Exception");
			    } 
			} // end of choice 3
			
			//*************************************************
			//else if statement for choice 4 which is to show
			//assignment by name.
			//*************************************************
			else if (choice == 4)
			{
				System.out.printf("Enter the Assignment Name: ");
				scn.nextLine();
				String arrayName = scn.nextLine();
				
				//*************************************************
				//if statement that either reports back the name
				//does not exist or then prints out the information.
				//*************************************************
				
				if (a1.GetByName(arrayName)== null)
				{
					System.out.println("That name does not exist.\n");
				}
				else
				{
					Assignment a = a1.GetByName(arrayName);
					
					String s;
					s = a.getName();
					s += "\n";
					s += a.getGrade();
					s += "\n";
					s += a.getCategory();
					s += "\n\n";
					System.out.printf("%s",s);
				}
			}//end of choice 4
			
			//*************************************************
			//else if statement for choice 5 which is to show
			//all data as JSON
			//*************************************************			
			else if (choice == 5)
			{
				System.out.println(a1.toString());
			}// end of choice 5
			
			//*************************************************
			//else if statement for choice 6 which is to show
			//all data as a report to the screen.
			//*************************************************	
			else if (choice == 6)
			{
				PrintStream ps = System.out;
				a1.Report(ps);
			}// end of choice 6
			
			//*************************************************
			//else if statement for choice 7 which exits the system.
			//*************************************************
			else if (choice == 7)
			{
				break;
			}// end of choice 7
		} 
		while(choice!=7);//end of while loop
		//scn.close();
	}// end of voidShowUI
}// end of AssignmentCollectionConsoleUI
