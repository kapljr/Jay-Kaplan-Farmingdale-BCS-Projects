/**
 * Contains a Course Member Swing UI
 * This program presents a GUI to the user and then presents a menu bar with a drop down
 * menu that has three choices, open, save, or exit.
 */
package jaykaplan.bcs345.hwk.grades.presentation;

/**
 * Contains Course Member Swing UI method ShowUI. 
 * This class creates a menu to the user and then perform 
 * an action depending on what the user chooses to do. 
 * When the program runs it display's the GUI menu to the user and 
 * gives them a chance to select a choice from the dropdown.
 * 
 * @author Jay Kaplan
 * @version 1.0
 * @since 12/4/2015
 *
 */
public class CourseMemberSwingUI 
{

	/**
	 * This method declares and creates an instance
	 * of the CourseMemberWindow, and makes the 
	 * window visible
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public void ShowUI()
	{
		//*************************************************
		//This creates a new instance of Course Member
		//Window and displays it. 
		//*************************************************
		CourseMemberWindow win = new CourseMemberWindow();
		win.setVisible(true);
	}
}
