/**
 * Contains Course Member Window.
 * This program presents a GUI menu to the user and then performs one 
 * of 3 actions depending on which choice the user chooses.
 */
package jaykaplan.bcs345.hwk.grades.presentation;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import jaykaplan.bcs345.hwk.grades.business.AssignmentCollection;
import jaykaplan.bcs345.hwk.grades.business.CourseMember;

/**
 * Contains Course Member Window method. 
 * This class creates a GUI menu to the user. This method uses extends
 * JFrame and implements ActionListener for event handling.
 * 
 * @author Jay Kaplan
 * @version 1.0
 * @since 12/4/2015
 *
 */
@SuppressWarnings("serial")
public class CourseMemberWindow extends JFrame implements ActionListener
{
	protected CourseMember coursemember;
	protected JMenuBar menuBar;
	protected JMenuItem openMenu, saveMenu, exitMenu;
	protected JTextField firstField, lastField, idField, majorField;
	protected JTextField  hwField, examField, overallField, quizField, labField;
 	
	/**
	 * This method is the default constructor. It calls for new coursemember
	 * variable, sets window size and title, sets default close operation
	 * creates the gui controls, and displays the gui controls in the window
	 * 
	 * @param not used.
	 * @return not used.
	 */
	public CourseMemberWindow()
	{
		//*****************************************************
		// Creates CourseMember member variable.
		// Sets the window size and title. 
		// Sets the default close operation to DISPOSE_ON_CLOSE.
		//*****************************************************
		coursemember = new CourseMember();
		setTitle("BCS 345"+" Course Member Report ");
		setSize(600,600);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		
		//*****************************************************
		//Menu Bar setup code - Code from Chap 22
		//*****************************************************
		menuBar = new JMenuBar();
		JMenu fileMenu = new JMenu("File");
		menuBar.add(fileMenu);
		setJMenuBar(menuBar);
		
		//*****************************************************
		//openMenu setup for menuBar
		//*****************************************************
		openMenu = new JMenuItem("Open...");
		openMenu.addActionListener(this); //when clicked it calls open action performed
		fileMenu.add(openMenu);//adds open to the menu
		fileMenu.addSeparator();
		
		//*****************************************************
		//saveMenu setup for menuBar
		//*****************************************************
		saveMenu = new JMenuItem("Save As...");
		saveMenu.addActionListener(this); //when clicked it calls save action performed
		fileMenu.add(saveMenu);//adds save to the menu
		fileMenu.addSeparator();//adds line separator
		
		//*****************************************************
		//exitMenu setup for menuBar
		//*****************************************************
		exitMenu = new JMenuItem("Exit");
		exitMenu.addActionListener(this); //when clicked it calls exit action performed
		fileMenu.add(exitMenu);//adds exit to the menu
		
		//*****************************************************
		//Creates Tabbed Panels - code from Chap 22
		//*****************************************************
		JTabbedPane courseMemberTabs = new JTabbedPane();
		add(courseMemberTabs);
		
		//*****************************************************
		//Sets up 2 Panels and adds it to JTabbedPane
		//*****************************************************
		JPanel studentPanel = new JPanel();
		JPanel gradePanel = new JPanel();
		courseMemberTabs.addTab("Student", studentPanel);
		courseMemberTabs.addTab("Grades", gradePanel);
		
		//*****************************************************
		//set layout using hint - GridLayout, 0 rows, 2 columns
		//*****************************************************
		studentPanel.setLayout(new GridLayout(0,2));
		gradePanel.setLayout(new GridLayout(0,2));

		//*****************************************************
		//Labels for Student Tab Panel
		//*****************************************************
		JLabel first = new JLabel("First");
		studentPanel.add(first);
		firstField = new JTextField();
		studentPanel.add(firstField);
				
		JLabel last = new JLabel("Last");
		studentPanel.add(last);
		lastField = new JTextField();
		studentPanel.add(lastField);
		
		JLabel id = new JLabel("Id");
		studentPanel.add(id);
		idField = new JTextField();
		studentPanel.add(idField);
						
		JLabel major = new JLabel("Major");
		studentPanel.add(major);
		majorField = new JTextField();
		studentPanel.add(majorField);
		
		//*****************************************************
		//Labels for Grades Tab Panel
		//*****************************************************
		JLabel exam = new JLabel("Exam Avg");
		gradePanel.add(exam);
		examField = new JTextField();
		gradePanel.add(examField);
				
		JLabel hw = new JLabel("Homework Avg");
		gradePanel.add(hw);
		hwField = new JTextField();
		gradePanel.add(hwField);
		
		JLabel quiz = new JLabel("Quiz Avg");
		gradePanel.add(quiz);
		quizField = new JTextField();
		gradePanel.add(quizField);
				
		JLabel lab = new JLabel("Lab Avg");
		gradePanel.add(lab);
		labField = new JTextField();
		gradePanel.add(labField);
		
		JLabel overall = new JLabel("Overall Grade");
		gradePanel.add(overall);
		overallField = new JTextField();
		gradePanel.add(overallField);
	}

	/**
	 * Allows the user to select Open, Save As, and Exit as menu items
	 * using JFileChooser which allows the user to decide which file to 
	 * read data from. 
	 * 
	 * @param evt Value of action being performed.
	 * @return not used.
	 */
	@Override
	public void actionPerformed(ActionEvent evt) 
	{
		//*********************************************
		//Event action when Open is selected
		//*********************************************
		if(evt.getSource() == openMenu)
		{
			//*********************************************
			//Code from Chap 15 - Opens JFileChooser
			//*********************************************
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int result = fileChooser.showOpenDialog(this);
			
			if(result == JFileChooser.APPROVE_OPTION)
			{
				File openFile = fileChooser.getSelectedFile();
				try 
				{
					//****************************************************
					//Assignment Collection is calculating the grades
					//and then the method is getting called here from
					//the coursemember variable
					//**NOTE**
					//Originally had valueof as shown in idField for all
					//of the avg fields, but decided to change to format
					//after seeing that you showed only one decimal place.
					//on spec doc. I googled Java Swing setText format
					//and decided that this looked closer to your specs.
					//*****************************************************
					Scanner fileName = new Scanner(new FileReader(openFile.getAbsolutePath()));
					coursemember.Read(fileName);
					AssignmentCollection assignments = coursemember.getAssignments();
					assignments.findGradeAvg();
					firstField.setText(coursemember.getStudent().getFirst());
					lastField.setText(coursemember.getStudent().getLast());
					idField.setText(String.valueOf(coursemember.getStudent().getId()));
					majorField.setText(coursemember.getStudent().getLast());
					hwField.setText(String.format("%.1f",assignments.hwGrade));
					examField.setText(String.format("%.1f",assignments.examGrade));
					quizField.setText(String.format("%.1f",assignments.quizGrade));
					labField.setText(String.format("%.1f",assignments.labGrade));
					overallField.setText(String.format("%.1f",assignments.overallGrade));
					
					//*********************************************
					//Resets the title of the window
					//*********************************************
					setTitle("BCS 345"+" "+coursemember.getStudent().getFirst()+" "+coursemember.getStudent().getLast()+" "+"Course Member Report");
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}//end of approve option if block
		}//end of event open block	
		
		//*********************************************
		//Event action when Save is selected
		//*********************************************
		if(evt.getSource() == saveMenu)
		{
			//*********************************************
			//Code from Chap 15 - Opens JFileChooser
			//*********************************************
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			int result = fileChooser.showSaveDialog(this);
			
			if(result == JFileChooser.APPROVE_OPTION)
			{
				File saveFile = fileChooser.getSelectedFile();
				try 
				{
					PrintStream ps = new PrintStream(saveFile.getAbsolutePath());
					coursemember.Write(ps);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}//end of approve option if block
		}// end of save option block
		if(evt.getSource() == exitMenu)
		{
			setVisible(false);
		}
	}// end of action performed block
}//end of Course Member Window